export interface ParsedSchedule {
    date: Date;
    time: string;
    title: string;
}

export const parseScheduleText = (text: string, currentYear: number, currentMonth: number): ParsedSchedule[] => {
    // Split lines and clean up, removing empty lines
    const lines = text.split('\n').map(line => line.trim()).filter(line => line.length > 0);
    const schedules: ParsedSchedule[] = [];

    let currentDate: Date | null = null;
    let currentTime: string | null = null;

    // Regex patterns
    // Date: "01 Thu", "26 Mon" (Start of line, 1 or 2 digits, space, 3 letter day)
    const dateRegex = /^(\d{1,2})\s+([A-Za-z]{3})/;
    // Time: "09:00 - 10:00" 
    const timeRegex = /^(\d{2}:\d{2})\s*-\s*\d{2}:\d{2}/;

    for (let i = 0; i < lines.length; i++) {
        const line = lines[i];

        // 1. Check for Date
        const dateMatch = line.match(dateRegex);
        if (dateMatch) {
            const day = parseInt(dateMatch[1], 10);
            // Create date object (Month is 0-indexed)
            currentDate = new Date(currentYear, currentMonth, day);
            continue;
        }

        // 2. Check for Time
        const timeMatch = line.match(timeRegex);
        if (timeMatch && currentDate) {
            currentTime = timeMatch[0]; // Extract full time string "09:00 - 10:00"

            // The NEXT non-empty line should be the title
            if (i + 1 < lines.length) {
                const titleLine = lines[i + 1];

                // Ensure the next line isn't another date or time
                if (!titleLine.match(dateRegex) && !titleLine.match(timeRegex)) {
                    schedules.push({
                        date: currentDate,
                        time: currentTime,
                        title: titleLine
                    });
                    // Skip the title line to avoid processing it again
                    i++;
                }
            }
            continue;
        }
    }

    return schedules;
};
